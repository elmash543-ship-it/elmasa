import 'package:flutter/material.dart';

void main() => runApp(AlmasaApp());

class AlmasaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'الماسة',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.green, fontFamily: 'Cairo'),
      home: HomeScreen(),
      locale: Locale('ar'),
    );
  }
}

class HomeScreen extends StatefulWidget { @override _HomeScreenState createState() => _HomeScreenState(); }

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  List<Map<String,dynamic>> requests = [
    {"type":"سباكة","desc":"تسريب في حمام طنطا - سيجر","price":"150","dist":"1.2 كم"},
    {"type":"كهرباء","desc":"مفتاح نور بيشرز - شارع البحر","price":"100","dist":"0.8 كم"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الماسة 💎 - Almasa'), backgroundColor: Color(0xFF00CC66), centerTitle: true),
      body: _index==0 ? _clientView() : _index==1 ? _feedView() : _craftsmanView(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index, onTap: (i)=> setState(()=> _index=i),
        selectedItemColor: Color(0xFF00CC66),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.add_home_work), label: 'اطلب'),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'الطلبات'),
          BottomNavigationBarItem(icon: Icon(Icons.handyman), label: 'شغلي'),
        ],
      ),
    );
  }

  Widget _clientView() {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(children: [
        DropdownButtonFormField(items: [DropdownMenuItem(child: Text('سباكة'), value: 'سباكة'), DropdownMenuItem(child: Text('كهرباء'), value: 'كهرباء')].toList(), decoration: InputDecoration(labelText: 'نوع الشغل'), onChanged: (v){}),
        SizedBox(height:12),
        TextField(maxLines:3, decoration: InputDecoration(labelText: 'ايه المشكلة؟', border: OutlineInputBorder())),
        SizedBox(height:12),
        TextField(keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'السعر اللي في دماغك (جنيه)', prefixText: 'ج ')),
        SizedBox(height:20),
        ElevatedButton(onPressed: (){ ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم نشر طلبك في الماسة!'))); }, child: Text('انشر في الماسة'), style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF00CC66), minimumSize: Size(double.infinity, 50)))
      ]),
    );
  }

  Widget _feedView() {
    return ListView.builder(
      itemCount: requests.length,
      itemBuilder: (c,i){
        var r = requests[i];
        return Card(margin: EdgeInsets.all(10), child: ListTile(
          leading: Icon(r['type']=='سباكة' ? Icons.plumbing : Icons.electrical_services, color: Color(0xFF00CC66)),
          title: Text('${r['type']} - ${r['dist']}'),
          subtitle: Text(r['desc']),
          trailing: Column(children: [Text('${r['price']} ج', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(height:4), ElevatedButton(onPressed: (){}, child: Text('قدم عرض'))]),
        ));
      },
    );
  }

  Widget _craftsmanView() {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      CircleAvatar(radius:40, backgroundColor: Color(0xFF00CC66), child: Icon(Icons.person, size:40, color: Colors.white)),
      SizedBox(height:10),
      Text('صنايعي الماسة', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold)),
      Text('⭐ 4.9 - 127 شغلانة', style: TextStyle(color: Colors.grey)),
      SizedBox(height:20),
      SwitchListTile(title: Text('متاح الآن'), value: true, onChanged: (v){}, activeColor: Color(0xFF00CC66)),
    ]));
  }
}