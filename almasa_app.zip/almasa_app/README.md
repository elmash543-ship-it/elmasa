# الماسة - Almasa
تطبيق زي اندرايف بس للصنايعية - مجاني

## ازاي تطلع APK ببلاش:
1. اعمل Repo جديد على github.com وارفع الملفات دي
2. دوس على Actions > هتلاقي Build running
3. بعد 4 دقايق حمل ملف app-release.apk من Artifacts
4. ارفعه على Firebase App Distribution وابعته للناس

Firebase مجاني 100% - اعمل مشروع في console.firebase.google.com

للتواصل: صنايعية طنطا